export type User = {
    username: string;
    role: string;
}