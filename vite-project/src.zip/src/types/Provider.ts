export type Provider = {
    providerId: number;
    providerName: string;
}